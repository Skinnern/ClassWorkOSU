//Nicholas Skinner
//Add to specific location in an array
//unsure if we should be using nodes or not, many online guides sort of flip flop if they're needed or not


public class LinkedListDriver{
public static void main(String[] args){
LinkedListMethods llf = new LinkedListMethods();
llf.run();
}
}

//put in exception if input is out of bounds