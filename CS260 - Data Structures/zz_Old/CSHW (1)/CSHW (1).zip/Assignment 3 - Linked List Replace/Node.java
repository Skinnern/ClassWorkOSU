class Node {
    Node next;
    int num;
    public Node(int val) {
        num = val;
        next = null;
    }
}