const express = require('express');
const bodyParser = require('body-parser');
const router = express.Router();
//our constants for express, body parser, as well as router


//our router should use bodyparser
router.use(bodyParser.json());
//our router should user urlencoded
router.use(bodyParser.urlencoded({extended:true}));










// setting up variables for oauth
const { google } = require('googleapis'); //we require the google apis to collect the user information
const client_id = "661727584854-aq8ut6bsde3p7c0g3diuvfv0gjl93eoi.apps.googleusercontent.com"; //the client id that was created by gcloud
var client_Secret = "hULpfTlU2_i5cizJvdxvy9ht"; //the client secret that was created by gcloud
const redirect = "https://skinnern-cs493-project6.appspot.com/oauth/auth"; //the redirect link that gcloud will check for validity



//construct the oauth variable, composed of the client id, the client secret, and the redirect 
var oauth2Client = new google.auth.OAuth2(
	client_id,
	client_Secret,
	redirect
);


//we want v1 of google people
const people = google.people('v1');

//set our auth option to oauth2Client
google.options({
	auth: oauth2Client
});
//
var client_State;

//*********************************************************************************************************************
//state maker
//we will want to create a state composed of random numbers and letters
function createState() {
	var state = "";//the state starts empty
	var selection = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";//the selection of variables for our state
	
	for (var i = 0; i < 5; i++) { //if our state is less than 5, continue producing new variables
		state += selection.charAt(Math.floor(Math.random() * selection.length)); //here we will append to the string for each loop through.
		//this should create a unique state that we can use
	}
	return state; //return the state
}
//end state maker
//*********************************************************************************************************************


//*********************************************************************************************************************
//router get
//we will use this to create a state,
//then we will go to authenticate with our client state
//this should return 200, sending the user home
router.get('/', function(req, res) {
	var context = {};
	
	client_State = createState();
	
	context.link = authenticate(client_State);
	
	res.status(200);
	res.render('home', context);
});
//end the router get
//*********************************************************************************************************************


//*********************************************************************************************************************
//getperson
//this function should be focused on getting the traits of the user
//we want their given name, and their family name
function getPerson() {
	return new Promise(function (resolve, reject) {
		const service = google.people({
			version: 'v1', 
			oauth2Client
		});//close service
		
		var req = service.people.get({
			resourceName: 'people/me',
			personFields: 'names',
		}, (error, response) => {
			if(!error) { //if there is no error, we can safely proceed to collect the user's name and family name
				const personInfo = response.data; //we will collect the response data in personInfo, so we can parse it later
				var person = {}; //create a object for the person
				person.givenName = personInfo.names[0].givenName; //grab the user's given name, to display later
				person.familyName = personInfo.names[0].familyName; //grab the user's family name, to display later
				resolve(person); //resolve our person object
			}
			else { //if we recieved an error, we will want to tell the user the bad news
				reject("there was no data"); //we don't have anything to display to the user
			}
		});//close our people get
	}); //close our promise	
} //close getperson
//end getperson
//*********************************************************************************************************************


//*********************************************************************************************************************
//authentication
//create the auth url
function authenticate() {
	var authUrl = oauth2Client.generateAuthUrl({ //this will just create a url searching for specific parts of the user's profile
		access_type: 'offline',
		scope: 'profile email', //specifies that we want to see their profile and email
	});
	authUrl = authUrl + "&state=" + client_State; //tje authUrl is a combination of our auth url, plus the client state
	return authUrl; //return the auth url 
}
//end authentication
//*********************************************************************************************************************


//*********************************************************************************************************************
//get authorize
//this should:
//grab the code from the req
//grab the returnstate from the req

//check the the return state is equal to our client state
//if it is equal, we want to set the credentials
//when the credentials are set, we can get the person's info
//if we error at any point, we can just kick ourselves out of the loop
router.get('/auth', function(req, res) {	 //get under our auth
	var returnState = req.query.state; //grab the return state to use to check our client
	var context = {}; //create context variable to store person
	var code = req.query.code; //grab the query code from the request

	//heres the big loop
	if (returnState == client_State) { //if our return state is equal to our client state,
		//we will use a post using the token we get back
		oauth2Client.getToken(code, (err, token) => {//send token and err variable from client
			if (!err) {//if there are no errors to report, we can continue
				oauth2Client.setCredentials(token); //set the credentials to our token
				
				//now that the credentials are set, we can start grabbing that login information
				var person = getPerson() //we will send a get to get the person
				.then( (person) => { //continue get person
					context = person; //set context to be person
					context.state = returnState;//the state for our context is now return, as we want to give this information to the client
					res.render('OAuth2', context); //send the data back to the client with the oauth2 handler, and the person inside of context
				});//end person request
			}//end if check for error
		})//end our token call	
	} //end the return state == client state check
}); //end function
//end get authorize
//*********************************************************************************************************************

//router
module.exports = router;