var express = require('express'); //we need express for our setup
var bodyParser = require('body-parser'); //we need body parser to parse our json
var app = express(); //initalize express as app
var handlebars = require('express-handlebars').create({defaultLayout:'main'}); //require our handlebars, the default layout should be main
//main is used in all other pages as a header with a navbar

//I was encountering a wall with setting this up in python that I couldn't really get past
//so I swapped over to javascript to see if i could resolve my issue
//after some more logging, i realized that I was using depricated google plus api documentation.
//I decided to keep going with javascript, as i got this far, so i could continue



//we will use the handlebars engine
app.engine('handlebars', handlebars.engine);

//we will use bodyparser to parse json we recieve
app.use(bodyParser.urlencoded({extended:true}));

//this lets us look up files which are set in the static directory
app.use('/static', express.static('public'));

//we will set our view engine to be focused on the handlebars
app.set('view engine', 'handlebars');

//we will use oauth2 to send/recieve info from our webpage
app.use('/oauth', require('./oauth.js'));


//404 out if there is nothing to display
app.use(function(req,res){
  res.status(404); //send the 404 status to the user
  res.render('404'); //render the 404 handlebar
});

//listening of port 8080 is this is a local service
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}...`);
});