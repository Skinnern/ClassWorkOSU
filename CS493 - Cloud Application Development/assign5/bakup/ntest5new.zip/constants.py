#this just houses constant string values between all of the .py files
#currently this is set to boats and loads for assignment 4
boats = "boats"