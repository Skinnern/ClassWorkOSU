package models;

import java.io.Serializable;

public enum Suit implements Serializable {
    Hearts, Spades, Diamonds, Clubs, Bastos, Oros, Copas, Espadas, Comodines
}

